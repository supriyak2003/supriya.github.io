from django.apps import AppConfig


class UserFavoritesConfig(AppConfig):
    name = 'user_favorites'
